package to.msn.wings.myfragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.Map;

public class DetailsFragment extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
        @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.details_fragment, container, false);
        Bundle bundle = getArguments();
        if (bundle != null) {
            Map<String, String> item = ListDataSource.getInfoByName(
                    bundle.getString("name"));
            ((TextView)view.findViewById(R.id.name)).setText(String.format(
                    "%s（%s）",bundle.getString("name"), item.get("alias")));
            ((TextView) view.findViewById(R.id.info)).setText(item.get("info"));
        }
        return view;
    }
}

